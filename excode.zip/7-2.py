num = []

num.extend([10, 20, 30])
num.insert(2, 40)

removed = num.pop()
print("삭제된 요소:", removed)

print("요소들의 합:", sum(num))